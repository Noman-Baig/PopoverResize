//
//  PopoverResize.h
//  PopoverResize
//
//  Created by David Boyd on 10/28/18.
//  Copyright © 2018 David Boyd. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//! Project version number for PopoverResize.
FOUNDATION_EXPORT double PopoverResizeVersionNumber;

//! Project version string for PopoverResize.
FOUNDATION_EXPORT const unsigned char PopoverResizeVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PopoverResize/PublicHeader.h>


